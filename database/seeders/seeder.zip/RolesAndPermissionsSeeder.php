<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\PermissionRegistrar;

class RolesAndPermissionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Reset cached roles and permissions
        app()[PermissionRegistrar::class]->forgetCachedPermissions();

        // Create Permissions
        $permissions = [
            'manage users',
            'manage roles',
            'manage menu',
            'manage tables',
            'view reports',
            'manage settings',
            'create orders',
            'view kitchen',
            'view bar',
            'view nan_pyar',
            'process payments',
            'manage expenses',
        ];

        foreach ($permissions as $permission) {
            Permission::firstOrCreate(['name' => $permission]);
        }

        // Create Roles and Assign Permissions

        // 1. Admin (Super User)
        $adminRole = Role::firstOrCreate(['name' => 'admin']);
        $adminRole->givePermissionTo(Permission::all());

        // 2. Cashier
        $cashierRole = Role::firstOrCreate(['name' => 'cashier']);
        $cashierRole->givePermissionTo([
            'create orders',
            'process payments',
            'manage expenses',
            'view reports',
            'manage tables',
        ]);

        // 3. Waiter
        $waiterRole = Role::firstOrCreate(['name' => 'waiter']);
        $waiterRole->givePermissionTo([
            'create orders',
            'manage tables',
        ]);

        // 4. Kitchen / Bar / Nan Pyar (Display Screens)
        $kitchenRole = Role::firstOrCreate(['name' => 'kitchen']);
        $kitchenRole->givePermissionTo(['view kitchen']);

        $barRole = Role::firstOrCreate(['name' => 'bar']);
        $barRole->givePermissionTo(['view bar']);
        
        $nanPyarRole = Role::firstOrCreate(['name' => 'nan_pyar']);
        $nanPyarRole->givePermissionTo(['view nan_pyar']);
    }
}
